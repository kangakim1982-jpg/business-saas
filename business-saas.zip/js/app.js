import {
  observeAuthState,
  logoutUser
} from "./services/auth.service.js";

import {
  setState,
  getState
} from "./core/state.js";

import { icon } from "./components/icons.js";
import { escapeHTML } from "./utils/helpers.js";

import {
  registerRoute,
  startRouter,
  navigate
} from "./router.js";

async function registerServiceWorker() {
  if (!("serviceWorker" in navigator)) return;

  try {
    await navigator.serviceWorker.register("./sw.js");
  } catch (error) {
    console.error("Service Worker:", error);
  }
}

function renderDashboard(container) {
  const { user, activeBusiness } = getState();

  const email = escapeHTML(user?.email || "");
  const initial = escapeHTML((user?.email || "U").charAt(0).toUpperCase());
  const businessName = activeBusiness?.name ? escapeHTML(activeBusiness.name) : "";

  const modules = [
    { icon: "sales", label: "Penjualan" },
    { icon: "inventory", label: "Inventaris" },
    { icon: "customers", label: "Pelanggan" }
  ];
  const management = [
    { icon: "finance", label: "Keuangan" },
    { icon: "reports", label: "Laporan" },
    { icon: "settings", label: "Pengaturan" }
  ];

  const lockedItem = (item) => `
    <div class="bs-nav-item is-locked" aria-disabled="true">
      ${icon(item.icon)}
      <span>${item.label}</span>
      <span class="bs-soon">Segera</span>
    </div>`;

  // Status langkah diambil dari state nyata, bukan data contoh.
  const steps = [
    {
      done: Boolean(user),
      title: "Akun",
      note: user ? "Sudah masuk" : "Belum masuk"
    },
    {
      done: Boolean(activeBusiness),
      title: "Ruang kerja bisnis",
      note: activeBusiness ? businessName : "Belum dibuat"
    },
    {
      done: false,
      title: "Modul operasional",
      note: "Penjualan, inventaris, pelanggan"
    }
  ];

  const heroTitle = !user
    ? "Anda belum masuk"
    : activeBusiness
      ? businessName
      : "Ruang kerja bisnis belum dibuat";

  const heroText = !user
    ? "Masuk dengan akun Anda untuk membuka ruang kerja bisnis."
    : activeBusiness
      ? "Ruang kerja aktif. Modul operasional akan muncul di sini saat tersedia."
      : "Buat ruang kerja untuk mulai mengelola penjualan, stok, pelanggan, dan keuangan.";

  const metrics = [
    { icon: "sales", tone: "blue", label: "Total penjualan" },
    { icon: "finance", tone: "green", label: "Total transaksi" },
    { icon: "inventory", tone: "blue", label: "Total produk" },
    { icon: "customers", tone: "green", label: "Total pelanggan" }
  ];

  container.innerHTML = `
    <div class="bs-layout">
      <aside class="bs-sidebar" id="bs-sidebar" aria-label="Navigasi utama">
        <div class="bs-brand">
          <div class="bs-brand-icon">${icon("store", 22)}</div>
          <div>
            <strong>Business SaaS</strong>
            <small>Untuk UMKM</small>
          </div>
          <button class="bs-close-menu" id="bs-close-menu" aria-label="Tutup menu">${icon("close")}</button>
        </div>

        <div class="bs-menu-label">Utama</div>
        <nav class="bs-navigation">
          <a class="bs-nav-item" href="#dashboard" aria-current="page" data-close>
            ${icon("dashboard")}<span>Dashboard</span>
          </a>
          ${modules.map(lockedItem).join("")}
        </nav>

        <div class="bs-menu-label">Manajemen</div>
        <nav class="bs-navigation">
          ${management.map(lockedItem).join("")}
        </nav>

        <div class="bs-sidebar-bottom">
          <div class="bs-user">
            <div class="bs-avatar">${initial}</div>
            <div class="bs-user-info">
              <strong>${email || "Pengunjung"}</strong>
              <small>${user ? "Akun aktif" : "Belum masuk"}</small>
            </div>
          </div>
          ${user ? `
            <button class="bs-logout" id="bs-logout">
              ${icon("logout", 18)}<span>Keluar</span>
            </button>` : ""}
        </div>
      </aside>

      <div class="bs-main">
        <header class="bs-header">
          <div class="bs-header-left">
            <button class="bs-menu-toggle" id="bs-menu-toggle" aria-label="Buka menu" aria-controls="bs-sidebar">
              ${icon("menu", 22)}
            </button>
            <div class="bs-header-title">
              <strong>Dashboard</strong>
              <small>${businessName || "Ringkasan bisnis"}</small>
            </div>
          </div>
          <div class="bs-header-right">
            <span class="bs-status"><i></i>Sistem aktif</span>
            <div class="bs-header-avatar" aria-hidden="true">${initial}</div>
          </div>
        </header>

        <div class="bs-content">
          <section class="bs-hero" aria-labelledby="bs-hero-title">
            <div>
              <h1 id="bs-hero-title">${heroTitle}</h1>
              <p>${heroText}</p>
            </div>
            <ol class="bs-steps">
              ${steps.map((step) => `
                <li class="bs-step ${step.done ? "is-done" : ""}">
                  <span class="bs-step-mark">${icon(step.done ? "check" : "lock", 16)}</span>
                  <div>
                    <strong>${step.title}</strong>
                    <small>${step.note}</small>
                  </div>
                </li>`).join("")}
            </ol>
          </section>

          <section class="bs-section" aria-labelledby="bs-summary-title">
            <div class="bs-section-heading">
              <h2 id="bs-summary-title">Ringkasan bisnis</h2>
              <p>Angka muncul setelah modul terkait aktif dan data tersimpan.</p>
            </div>
            <dl class="bs-metrics">
              ${metrics.map((m) => `
                <div class="bs-metric">
                  <div class="bs-metric-icon ${m.tone}">${icon(m.icon)}</div>
                  <dt>${m.label}</dt>
                  <dd class="value">—</dd>
                  <dd class="hint">Belum ada data</dd>
                </div>`).join("")}
            </dl>
          </section>

          <footer class="bs-footer">
            <span>Business SaaS</span>
            <span>Versi pengembangan</span>
          </footer>
        </div>
      </div>
    </div>

    <div class="bs-overlay" id="bs-overlay"></div>
  `;

  const sidebar = container.querySelector("#bs-sidebar");
  const overlay = container.querySelector("#bs-overlay");
  const toggle = container.querySelector("#bs-menu-toggle");

  function setMenu(open) {
    sidebar.classList.toggle("open", open);
    overlay.classList.toggle("show", open);
    document.body.classList.toggle("bs-lock", open);
    toggle.setAttribute("aria-expanded", String(open));
  }

  toggle.addEventListener("click", () => setMenu(true));
  container.querySelector("#bs-close-menu").addEventListener("click", () => setMenu(false));
  overlay.addEventListener("click", () => setMenu(false));
  container.querySelectorAll("[data-close]").forEach((el) =>
    el.addEventListener("click", () => setMenu(false))
  );
  document.addEventListener("keydown", function onKey(event) {
    if (!document.body.contains(sidebar)) {
      document.removeEventListener("keydown", onKey);
      return;
    }
    if (event.key === "Escape") setMenu(false);
  });

  const logoutButton = container.querySelector("#bs-logout");

  if (logoutButton) {
    logoutButton.addEventListener("click", async () => {
      try {
        await logoutUser();
      } catch (error) {
        console.error("Logout gagal:", error);
      }
    });
  }
}

registerRoute("dashboard", renderDashboard);

function initializeApp() {
  setState({ isLoading: true });

  registerServiceWorker();
  startRouter("dashboard");

  observeAuthState((user) => {
    setState({
      user: user || null,
      isLoading: false,
      isInitialized: true
    });

    navigate("dashboard");
  });
}

initializeApp();
